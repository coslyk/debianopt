# CSS

The css module for Textadept.
It provides utilities for editing CSS code.

---
