### This is the official repository for python extensions.

This repository is shipped with albert. If you want to have bleeding edge extensions or share your extension clone the repository. Check the docs on Python extensions.

To install the extensions in user space type the following in your terminal:

```
git clone https://github.com/albertlauncher/python.git ~/.local/share/albert/org.albert.extension.python/modules
```

If you send a PR I'll invite you to the reviewers team (if I don't forget it), I'd appreciate if you could review others contributions.
