#!/bin/bash

gtk-update-icon-cache  -f .

